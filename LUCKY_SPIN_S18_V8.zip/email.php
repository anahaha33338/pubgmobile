<?php
$emailku = 'akugungrate0@gmail.com';
?>