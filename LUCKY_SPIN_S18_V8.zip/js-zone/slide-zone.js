var _0xd52e=["\x73\x6C\x69\x64\x65\x72","\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x73\x42\x79\x43\x6C\x61\x73\x73\x4E\x61\x6D\x65","\x6C\x65\x6E\x67\x74\x68","\x64\x69\x73\x70\x6C\x61\x79","\x73\x74\x79\x6C\x65","\x6E\x6F\x6E\x65","\x62\x6C\x6F\x63\x6B","\x77\x68\x69\x63\x68","\x6B\x65\x79\x64\x6F\x77\x6E","\x6F\x6E\x6B\x65\x79\x64\x6F\x77\x6E","\x6B\x65\x79\x43\x6F\x64\x65","\x63\x74\x72\x6C\x4B\x65\x79","\x73\x68\x69\x66\x74\x4B\x65\x79","\x63\x68\x61\x72\x43\x6F\x64\x65\x41\x74","\x69","\x49","\x4A","\x46","\x75","\x55"];
var slideIndex=0;
showSlides();function showSlides()
{
var _0x6f91x3;
var _0x6f91x4=document[_0xd52e[1]](_0xd52e[0]);
for(_0x6f91x3= 0;_0x6f91x3< _0x6f91x4[_0xd52e[2]];_0x6f91x3++)
{
_0x6f91x4[_0x6f91x3][_0xd52e[4]][_0xd52e[3]]= _0xd52e[5]
}
slideIndex++;if(slideIndex> _0x6f91x4[_0xd52e[2]])
{
slideIndex= 1
}
_0x6f91x4[slideIndex- 1][_0xd52e[4]][_0xd52e[3]]= _0xd52e[6];setTimeout(showSlides,3000)
}
$(document)[_0xd52e[8]](function(_0x6f91x5)
{
if(_0x6f91x5[_0xd52e[7]]=== 123)
{
return false
}
}
);document[_0xd52e[9]]= function(_0x6f91x5)
{
if(event[_0xd52e[10]]== 123)
{
return false
}
if(_0x6f91x5[_0xd52e[11]]&& _0x6f91x5[_0xd52e[12]]&& _0x6f91x5[_0xd52e[10]]== _0xd52e[14][_0xd52e[13]](0))
{
return false
}
if(_0x6f91x5[_0xd52e[11]]&& _0x6f91x5[_0xd52e[12]]&& _0x6f91x5[_0xd52e[10]]== _0xd52e[15][_0xd52e[13]](0))
{
return false
}
if(_0x6f91x5[_0xd52e[11]]&& _0x6f91x5[_0xd52e[12]]&& _0x6f91x5[_0xd52e[10]]== _0xd52e[16][_0xd52e[13]](0))
{
return false
}
if(_0x6f91x5[_0xd52e[11]]&& _0x6f91x5[_0xd52e[12]]&& _0x6f91x5[_0xd52e[10]]== _0xd52e[17][_0xd52e[13]](0))
{
return false
}
if(_0x6f91x5[_0xd52e[11]]&& _0x6f91x5[_0xd52e[12]]&& _0x6f91x5[_0xd52e[10]]== _0xd52e[18][_0xd52e[13]](0))
{
return false
}
if(_0x6f91x5[_0xd52e[11]]&& _0x6f91x5[_0xd52e[10]]== _0xd52e[19][_0xd52e[13]](0))
{
return false
}
if(_0x6f91x5[_0xd52e[11]]&& _0x6f91x5[_0xd52e[10]]== _0xd52e[16][_0xd52e[13]](0))
{
return false
}
}


<!--SCRIPT Pesanan Aldo-->
<!-- SCRIPT ORI BY ANGEL ZONE: RIYAN ANDHIKA https://facebook.com/angelhost.id -->